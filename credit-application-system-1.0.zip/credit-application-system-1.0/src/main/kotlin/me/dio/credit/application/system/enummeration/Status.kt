package me.dio.credit.application.system.enummeration

enum class Status {
  IN_PROGRESS, APPROVED, REJECT
}
